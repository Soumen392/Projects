/ - register and log-in screen
/register
/log-in
/profile - profile page with boards
/feed - feed page with all different pins
/save/:pinid - save the pins in boards
/delete/:pinid - delete the pin from board
/logout
/edit
/upload 